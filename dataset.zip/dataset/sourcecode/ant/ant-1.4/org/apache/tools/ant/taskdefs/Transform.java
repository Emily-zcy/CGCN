package org.apache.tools.ant.taskdefs;

/**
 * Has been merged into ExecuteOn, empty class for backwards compatibility.
 *
 * @author <a href="mailto:stefan.bodewig@epost.de">Stefan Bodewig</a> 
 */
public class Transform extends ExecuteOn {}
