package org.apache.tools.ant.taskdefs.optional.depend;


public interface ClassFileIterator {

    public ClassFile getNextClassFile();
}
