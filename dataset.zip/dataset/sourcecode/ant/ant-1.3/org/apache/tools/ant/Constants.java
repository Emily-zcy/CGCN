package org.apache.tools.ant;

/**
 * Abstract interface to hold constants.
 * 
 * @author <a href="mailto:donaldp@apache.org">Peter Donald</a>
 */
interface Constants {
}
